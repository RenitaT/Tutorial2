public class ArrayUtility {

    public static void main(String[] args) {
        // 1
        int myInt = 65;
        // 2
        int myInt2 = 4;
        // 3
        double myDouble = 2.5;
        // 4
        char myChar = 'A';
        // 5
        System.out.println(myInt/myDouble);
        //6
        System.out.println(myInt/myInt2);

        // 8
        int myInt3 = (int)myDouble;

        // 9
        System.out.println(myInt3);

        // 11
        //System.out.println(12/0);

        // 12
        System.out.println(12.0/0);

        //13
        double myDouble2 = 4.6;
        //14
        double myDouble3 = 4.4;
        //15
        double myDouble4 = 4.5;
        //16
        myDouble2 += 0.5;

        // 17
        int myBigDouble2 = (int)myDouble2;

        System.out.println(myBigDouble2);

        // 18
        myDouble3 += 0.5;
        int myBigDouble3 = (int)myDouble3;

        System.out.println(myBigDouble3);

        // 21
        myDouble4 += 0.5;
        int myBigDouble4 = (int)myDouble4;

        // 23
        System.out.println(myBigDouble4);

        int Achar = (int)myChar;
        System.out.println(Achar);

        // 24
        char renita = (char)myInt;
        System.out.println(renita);

        //25
        int myInt4 = 7;

        //26
        System.out.println(myInt4);

        //27
        System.out.println(myInt4++);

        //28
        System.out.println(myInt4);

        //29
        System.out.println(++myInt4);

        //31
        System.out.println(145%10);

        //32
        System.out.println(178%10);

        //34
        System.out.println(10%2);

        //35
        System.out.println(11%2);

        //36
        System.out.println(12%2);

        //god bless bro.
    }



}
